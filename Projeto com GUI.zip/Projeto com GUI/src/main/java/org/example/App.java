package org.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * JavaFX App - Conexão Central de Todas as Classes e Modelos
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) throws IOException {
        conectarTodasAsClasses();

        scene = new Scene(loadFXML("primary"), 640, 480);
        stage.setTitle("Sistema Integrado - Modelos e Exercícios");
        stage.setScene(scene);
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

    public static void conectarTodasAsClasses() {
        System.out.println("INICIANDO CONEXÃO DE TODAS AS CLASSES");

        // GRUPO 1: LOJA DE ROUPAS
        Roupa roupa = new Roupa("Camisa", "M", 80.00, "Azul", "Dorinho's");
        Calcado calcado = new Calcado("Tênis Casual", 41, 199.90, "Branco");
        Acessorio acessorio = new Acessorio("Relógio de Pulso", "Couro", 120.00);
        Loja loja = new Loja("Dorinho's SJC", "Av. Eng. Sao Jose", "Carlos");

        System.out.println("[Loja] " + loja.getNome() + " | Gerente: " + loja.getGerente());
        System.out.println(" -> Produto: " + roupa.getTipo() + " | Marca: " + roupa.getMarca() + " | Preço: R$ " + roupa.getPreco());
        System.out.println(" -> Calçado: " + calcado.getModelo() + " | Numeração: " + calcado.getNumeracao());
        System.out.println(" -> Acessório: " + acessorio.getNome() + " (" + acessorio.getMaterial() + ")");
        roupa.vestir();

        // GRUPO 2: BICICLETAS E TRILHA
        Bicicleta bicicleta = new Bicicleta("Caloi", 3, 10.0, "Mountain Bike", 14.5);
        Ciclista ciclista = new Ciclista("Mariana", 22, 150.0);
        Trilha trilha = new Trilha("Trilha das Araucárias", 12.5, "Difícil");
        Capacete capacete = new Capacete("Pro-Tec", "M", true);

        System.out.println("\n[Trilha] " + trilha.getNome() + " (" + trilha.getExtensaoKm() + " km)");
        System.out.println(" -> Ciclista: " + ciclista.getNome() + " pedalando bicicleta " + bicicleta.getMarca());
        System.out.println(" -> Equipamento: Capacete " + capacete.getMarca() + " (Tamanho: " + capacete.getTamanho() + ")");
        bicicleta.pedalar();

        // GRUPO 3: MÁSCARAS AFRICANAS
        Mascara mascara = new Mascara();
        mascara.mascara("Marrom", 20.0, "Sul Africano", "Madeira", "Cerimonial");
        Tribo tribo = new Tribo("Zulu", "África do Sul", 45000);
        Ritual ritual = new Ritual("Celebração da Colheita", "Prosperidade", "Amanhecer");
        Colecionador colecionador = new Colecionador("Antônio", 25, "Brasil");

        System.out.println("\n[Máscara] Estilo: " + mascara.getEstilo() + " | Material: " + mascara.getMaterial());
        System.out.println(" -> Tribo de Origem: " + tribo.getNome() + " (" + tribo.getRegiao() + ")");
        System.out.println(" -> Ritual: " + ritual.getNome() + " | Adquirido por: " + colecionador.getNome());
        mascara.pintar("Azul");

        // GRUPO 4: CABELOS E MANGÁ
        Cabelo cabelo = new Cabelo("Preto", 30.0, "Repicado", "Ondulado", "Fino");
        Personagem personagem = new Personagem("Sasuke", "Naruto", 9500);
        SalaoBeleza salao = new SalaoBeleza("Anime Style Studio", "Renata", 8500.00);
        Tintura tintura = new Tintura("ColorExpress", "Vermelho Fogo", true);

        System.out.println("\n[Mangá/Cabelo] Personagem: " + personagem.getNome() + " (" + personagem.getAnime() + ")");
        System.out.println(" -> Cabelo: " + cabelo.getEstilo() + " | Cor: " + cabelo.getCor());
        System.out.println(" -> Salão: " + salao.getNome() + " | Tintura usada: " + tintura.getCor());
        cabelo.pentear();

        System.out.println("TODAS AS CLASSES CONECTADAS COM SUCESSO!");
    }
}