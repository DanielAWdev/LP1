package org.example;

import javafx.fxml.FXML;
import java.io.IOException;

public class PrimaryController {

    // --- Exercícios ---
    @FXML private void abrirExercicio1() throws IOException { App.setRoot("exercicio1"); }
    @FXML private void abrirExercicio2() throws IOException { App.setRoot("exercicio2"); }
    @FXML private void abrirExercicio3() throws IOException { App.setRoot("exercicio3"); }
    @FXML private void abrirExercicio4() throws IOException { App.setRoot("exercicio4"); }
    @FXML private void abrirExercicio5() throws IOException { App.setRoot("exercicio5"); }
    @FXML private void abrirExercicio6() throws IOException { App.setRoot("exercicio6"); }
    @FXML private void abrirExercicio7() throws IOException { App.setRoot("exercicio7"); }

    // --- Modelos Imagem 1 (Loja) ---
    @FXML private void abrirRoupa() throws IOException { App.setRoot("roupa"); }
    @FXML private void abrirCalcado() throws IOException { App.setRoot("calcado"); }
    @FXML private void abrirAcessorio() throws IOException { App.setRoot("acessorio"); }
    @FXML private void abrirLoja() throws IOException { App.setRoot("loja"); }

    // --- Modelos Imagem 2 (Bicicletas) ---
    @FXML private void abrirBicicleta() throws IOException { App.setRoot("bicicleta"); }
    @FXML private void abrirCiclista() throws IOException { App.setRoot("ciclista"); }
    @FXML private void abrirTrilha() throws IOException { App.setRoot("trilha"); }
    @FXML private void abrirCapacete() throws IOException { App.setRoot("capacete"); }

    // --- Modelos Imagem 3 (Máscaras) ---
    @FXML private void abrirMascara() throws IOException { App.setRoot("mascara"); }
    @FXML private void abrirTribo() throws IOException { App.setRoot("tribo"); }
    @FXML private void abrirRitual() throws IOException { App.setRoot("ritual"); }
    @FXML private void abrirColecionador() throws IOException { App.setRoot("colecionador"); }

    // --- Modelos Imagem 4 (Cabelo / Mangá) ---
    @FXML private void abrirCabelo() throws IOException { App.setRoot("cabelo"); }
    @FXML private void abrirPersonagem() throws IOException { App.setRoot("personagem"); }
    @FXML private void abrirSalaoBeleza() throws IOException { App.setRoot("salaobeleza"); }
    @FXML private void abrirTintura() throws IOException { App.setRoot("tintura"); }
}