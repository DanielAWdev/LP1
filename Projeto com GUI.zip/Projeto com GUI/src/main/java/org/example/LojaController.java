package org.example;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.io.IOException;

public class LojaController {
    @FXML private TextField txtNome;
    @FXML private TextField txtEndereco;
    @FXML private TextField txtGerente;
    @FXML private Label lblResultado;

    @FXML
    private void registrarLoja() {
        Loja loja = new Loja(
                txtNome.getText(),
                txtEndereco.getText(),
                txtGerente.getText()
        );
        lblResultado.setText(String.format("Loja %s localizada em %s (Gerente: %s)",
                loja.getNome(), loja.getEndereco(), loja.getGerente()));
    }

    @FXML private void voltar() throws IOException { App.setRoot("primary"); }
}